# Stock Gallery Helper

Please find instructions for installing and using this extension at https://github.com/adobe/stock-api-samples/blob/master/StockGalleryHelper/README.md.
